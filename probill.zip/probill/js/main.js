$(document).ready(function(){
    $("button").click(function(){
        $("#pageTitle").replaceWith($('#partial_index'));
    });
});